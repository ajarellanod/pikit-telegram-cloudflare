// Public surface of @pikit/contracts (SPEC §3): the vocabulary components share. Types, identities,
// names of events and pipelines, capability interfaces, two protocol functions (`admitInbound` in,
// `startAnswerDelivery` out: the paths every channel must get right, written and tested once), the
// check of what the contracts take as a JSON object (`isJsonObject`), the grammar of `http.route`
// keys (`parseHttpRouteKey`, `matchesHttpRoute`) and the envelope of an actor's call (`answerCall`,
// `callResult`), so that no provider has its own. No policy: what a protocol waits, retries and says
// is its caller's, passed in. Each contract has a stability level (SPEC K8); the capabilities'
// levels are in the catalogue (`packages/cli/src/registry/capabilities.ts`). What only Cloudflare
// components use (`WORKERS_HOST`) is in `@pikit/contracts/cloudflare`, not here.

export { defineAgent } from "./agent.ts";
export type {
  Admission,
  AgentConversations,
  AgentDefinition,
  AgentMessage,
  AgentPayloads,
  AgentRequest,
  AgentResult,
  AgentRuntime,
  AgentTool,
  ConversationRef,
  PrepareContext,
  TurnConfig,
  Usage,
} from "./agent.ts";

export type { AgentCommand, CommandInfo, CommandLookup, CommandOutcome } from "./command.ts";
export { COMMAND_NAME, commandProblem, isCommandName, listAgentCommands, runAgentCommand } from "./command.ts";
export type { CompletionRequest, ModelComplete } from "./model.ts";

export { admitInbound } from "./inbound.ts";
export type { AdmitOptions, InboundMessage, InboundOutcome, RouteDecision } from "./inbound.ts";

export type { AgentState } from "./agent-state.ts";
export { AGENT_STATE } from "./agent-state.ts";
export { CONVERSATION } from "./conversation-context.ts";
export type { ConversationRegistry, ConversationReset } from "./conversations.ts";
export type { HttpRoute, HttpRouteKey } from "./http.ts";
export { compareHttpRoutes, HTTP_ROUTE_KEY, matchesHttpRoute, parseHttpRouteKey } from "./http.ts";
export type { SecretStore } from "./secrets.ts";
export { REDACTED, redactSecrets, secretLikePaths } from "./secrets.ts";
export type { AgentObserver, ObservedConversation, ObservedEvent, ObservedPage, PageRequest, TranscriptEntry } from "./observe.ts";
export type { AdminAuth, AdminSessions, Operator } from "./admin.ts";
export { ADMIN_CLIENT_HEADER } from "./admin.ts";
export type { ComponentHealth, HealthRegistry, HealthReporter, HealthSnapshot, HealthStatus } from "./health.ts";
export type { Settings, SettingsErrorCode, SettingsSchema, SettingsSection, SettingsValue } from "./settings.ts";
export { SettingsError } from "./settings.ts";
export type { JsonValue } from "./json.ts";
export { isJsonObject } from "./json.ts";
export type { KeyValueStorage, KeyValueStore, SqlDatabase, SqlRow, SqlStatements, SqlValue } from "./storage.ts";
export type { Feed, FeedItem, FeedPage } from "./feed.ts";
export type { ActorCallErrorCode, ActorCallHandler, ActorCallOutcome, ActorInbox, ActorInboxHandler, ActorMailbox } from "./actor.ts";
export { ActorCallError, answerCall, callResult } from "./actor.ts";
export type { WakeupHandler, Wakeups } from "./wakeups.ts";
export type { AgentSubmissions, PendingConversation, RunSettlement, SubmissionStatus } from "./submissions.ts";
export type {
  ChannelTransport,
  DeliveryErrorKind,
  DeliveryReceipt,
  OutboundMessage,
  OutboundPiece,
  OutboundQueue,
  PendingPiece,
} from "./outbound.ts";
export { answerKey, DeliveryError } from "./outbound.ts";
export type { AnswerDelivery, AnswerDeliveryOptions, DeliveryPolicy } from "./delivery.ts";
export { answersOnlyTheDashboard, DASHBOARD_REQUEST_PREFIX, isDashboardRequest, startAnswerDelivery } from "./delivery.ts";
